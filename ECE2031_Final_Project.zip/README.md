# ECE2031_FinalProject
The scope of this project is to essentially implement PWM for LEDs at the hardware level.
Currently we have devised that we will require Hardware and Software teams. The scope of
hardware is to implement the LED peripheral with the DE10 board. The software team will 
concurrently devise an approach to interface with the LED and control the duty cycle of 
the LED.

Project Members:
- Prachit Amin
- Sitong "Stone" Li
- Shreyas Sakharkar
- Dylan Paige
- Jared Santiago
